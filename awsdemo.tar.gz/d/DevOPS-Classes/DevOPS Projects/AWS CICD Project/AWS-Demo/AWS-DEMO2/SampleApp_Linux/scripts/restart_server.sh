#!bin/bash
systemctl restrt nginx